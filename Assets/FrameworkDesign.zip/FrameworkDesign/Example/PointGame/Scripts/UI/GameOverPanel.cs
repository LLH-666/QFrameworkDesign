namespace FrameworkDesign.Example
{
    public class GameOverPanel : AbstractPointGameController
    {
    }
}