namespace FrameworkDesign.Example
{
    public struct OnCountDownEndEvent
    {
        
    }
}