using System;

namespace FrameworkDesign.Example
{
    public struct GameStartEvent
    {
    }
}
