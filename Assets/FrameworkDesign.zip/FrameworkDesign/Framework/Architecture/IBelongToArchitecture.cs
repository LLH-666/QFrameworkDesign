namespace FrameworkDesign
{
    public interface IBelongToArchitecture
    {
        IArchitecture GetArchitecture();
    }
}